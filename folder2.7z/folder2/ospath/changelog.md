1.2.2 / 2016-09-06
------------------
- fix `files` field

1.2.0 / 2016-09-06
------------------
- upgrade to Standard@v8
- fix tests
- added `desktop()` function

1.1.0 / 2015-06-17
------------------
- if `os.homedir()` is available, use it for `home()`

1.0.2 / 2015-06-16
------------------
- fixed bad `files` field in `package.json`

1.0.1 / 2015-06-16
------------------
- only include specific files

1.0.0 / 2015-06-16
------------------
- initial release
