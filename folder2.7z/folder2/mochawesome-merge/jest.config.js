module.exports = {
  testMatch: ['<rootDir>/tests/**/*.js'],
  collectCoverageFrom: ['<rootDir>/lib/**/*.js'],
}
