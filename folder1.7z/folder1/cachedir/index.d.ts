/** Return path to an appropriate place to store cache files. */
declare function cachedir (id: string): string
export = cachedir
