# `-`

> Created using https://github.com/parzh/create-package-typescript

```
npm i -
```
